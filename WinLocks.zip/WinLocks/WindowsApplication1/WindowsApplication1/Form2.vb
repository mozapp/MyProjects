﻿Public Class Form2
    
    Private Sub LogOutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogOutToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Label3.Text = Val(txtMin.Text)
        Label4.Text = Val(txtHour.Text)
        Timer1.Enabled = True

        'This Line Disable the textbox and start button when timer state
        If Timer1.Enabled = True Then
            txtMin.Enabled = False
            txtHour.Enabled = False
            Button1.Enabled = False
        End If



    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Stop()

    End Sub

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim a As Integer
        Dim b As Integer
        Dim d As Integer
        a = Label1.Text
        d = Label3.Text
        b = 1
        Label1.Text = a - b
        If Label1.Text = "0" Then
            Label3.Text = d - b
            Label1.Text = "60"

            'Hour Start here
            If Label3.Text = "0" Then
                Label4.Text = Label4.Text - 1
            ElseIf Label4.Text <= 1 Then
                MsgBox("Your Time is Up, Please buy more time")
                Timer1.Enabled = False
                Label1.Text = "0"
                Form1.Show()
                Me.Close()
            End If
            
        End If

        

    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If Label2.Visible = False Then
            Label2.Visible = True
        Else
            Label2.Visible = False
        End If
    End Sub
End Class