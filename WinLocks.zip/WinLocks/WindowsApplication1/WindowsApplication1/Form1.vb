﻿Imports System.Data.OleDb
Public Class Form1

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()

    End Sub

    Private Sub RegisterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegisterToolStripMenuItem.Click
        If gReg.Visible = False Then
            gReg.Show()
            gLogin.Hide()
        End If

    End Sub

    Private Sub LogInToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogInToolStripMenuItem.Click
        If gLogin.Visible = False Then
            gLogin.Show()
            gReg.Hide()

        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If TextBox1.Text = "1Time" And ComboBox1.SelectedIndex = "0" Then
            Form2.Show()
            Me.Hide()
        ElseIf TextBox1.Text = "1Time" And ComboBox1.SelectedIndex = "1" Then
            Form2.Show()
            Me.Hide()
        Else

            MsgBox("Please enter correct PAssword")
        End If

        TextBox1.Clear()
        TextBox1.Focus()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Dim sqlconn As New OleDb.OleDbConnection
            Dim sqlquery As New OleDb.OleDbCommand
            Dim connString As String
            connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\STAFF 2\Pictures\WinLocks\WindowsApplication1\WindowsApplication1\UserDataBase.mdb"
            sqlconn.ConnectionString = connString
            sqlquery.Connection = sqlconn
            sqlconn.Open()
            sqlquery.CommandText = "INSERT INTO UserTb1([Username], [Password], [P_Number], [Email])VALUES(@Username, @Password, @P_Number, @Email)"
            sqlquery.Parameters.AddWithValue("@Username", TextBox2.Text)
            sqlquery.Parameters.AddWithValue("@Username", TextBox4.Text)
            sqlquery.Parameters.AddWithValue("@Username", TextBox3.Text)
            sqlquery.Parameters.AddWithValue("@Password", TextBox5.Text)
            sqlquery.ExecuteNonQuery()
            sqlconn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class
